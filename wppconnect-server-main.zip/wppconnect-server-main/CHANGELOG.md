## 1.1.11 (2021-11-16)



## 1.1.10 (2021-11-12)



## 1.1.9 (2021-11-08)



## 1.1.8 (2021-11-08)



## 1.1.7 (2021-10-21)



## 1.1.6 (2021-10-13)


### Bug Fixes

* block/unblock contato. ([9401b16](https://github.com/wppconnect-team/wppconnect-server/commit/9401b168ce08eb62c5ea392db82df34b69753775))



## 1.1.5 (2021-10-01)



## 1.1.4 (2021-09-22)



## 1.1.3 (2021-08-13)



## 1.1.2 (2021-08-11)



## 1.1.1 (2021-08-06)



# 1.1.0 (2021-08-04)



## 1.0.3 (2021-07-15)

## 1.0.2 (2021-07-14)

## [1.0.1](https://github.com/wppconnect-team/wppconnect-server/compare/v1.0.0...v1.0.1) (2021-06-13)

### Bug Fixes

- Archive only unarchived chats ([#37](https://github.com/wppconnect-team/wppconnect-server/issues/37)) ([5985296](https://github.com/wppconnect-team/wppconnect-server/commit/5985296d97a9ccb19625e7ddbc07ecacc0ce65c6))
- Corrigido a entrada principal de arquivo JS ([f513c64](https://github.com/wppconnect-team/wppconnect-server/commit/f513c64247fe01e9297df27036ad1141278e87c2))
